# Ptrace Wrap Class - 2011
#
# Author: Giuseppe 'evilcry' Bonfa
#


import os
import sys

try:
    from ptrace.debugger.debugger import PtraceDebugger
    from ptrace.debugger.memory_mapping import readProcessMappings
except:
    print("Please Install Python-Ptrace")
    
class DebugEngine:
    def __init__(self, pid):
        try:
            debug = PtraceDebugger()
            self.process = debug.addProcess(int(pid), False)
            self.PID = pid
        except:
            print("Unable to Start Debugger for the Current Process!")
            return False
        
class MemoryDumper(DebugEngine):

    def getMemoryRegions(self):
        memoryMap = readProcessMappings(self.process)
        if len(memoryMap) == 0:
            return False
        else:
            self.memoryRegions = memoryMap
            return True
    
    def Dump(self):
        try:
            fregion = open(str(self.PID),'w')
            for mapEntry in self.memoryRegions:
                if "r" in mapEntry.permissions:
                    dump = self.process.readBytes(mapEntry.start,mapEntry.end-mapEntry.start)
                    fregion.write(dump)
                    continue                                        
                else:
                    continue            
            fregion.close()
            return True                    
        except:
            print("Error While Dumping")
            return False

        
