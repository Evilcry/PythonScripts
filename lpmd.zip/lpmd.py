# Ptrace based Linux Process Memory Dumper - 2011
#
# Author: Giuseppe 'evilcry' Bonfa
#
# This module imports debugger, given a pid dumps it

import os 
import sys
from dbgeng import *

from optparse import OptionParser



def main():
    print("+-------------------------------+")
    print("+--Linux Process Memory Dumper--+")
    print("+-------------------------------+")
    
    usage = "%Prog pid\n"
    description = "Given a PID Dump Available Memory\n"


    parser = OptionParser(usage = usage, description = description,
    version = "1.0")

    (options, args) = parser.parse_args()

    if len(args) < 1:
        print("Please Specify the  Process ID")
        sys.exit(-1)
    else:
        pid = args[0]
        if not pid.isdigit():
            print("Insert a valid PID")
            sys.exit(-1)
        else:
            memoryHandler = MemoryDumper(pid)
            
            if not memoryHandler.getMemoryRegions():
                print("Error During Memory Acquisition")
                return
            else:
                if not memoryHandler.Dump():
                    print("Unable to Dump Process Memory")
                    return
                else:
                    print("Correctly Dumped!")
                    return
        
    pass
    
if __name__ == '__main__':
    main()
